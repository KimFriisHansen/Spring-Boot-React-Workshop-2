package com.bestseller.springboot.bsspringboot.model;

public class Device {
    String name;
    String description;

    public Device(String name, String description) {
        this.name = name;
        this.description = description;
    }
    // Getter
    public String getName() {
        return name;
    }

    // Setter
    public void setName(String newName) {
        this.name = newName;
    }
}
