package com.bestseller.springboot.bsspringboot.controller;


import com.bestseller.springboot.bsspringboot.model.Device;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;
import org.springframework.http.MediaType;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;
import static org.springframework.http.HttpStatus.OK;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import java.util.HashMap;

/**
 * @author Kim
 */
@RestController
public class TestController {


    @RequestMapping("/test1")
    public String test1() {
        return "Hello";
    }
    //@CrossOrigin(origins = "http://localhost:3000")
    //@RequestMapping("/devices")
    @GetMapping(value = "/devices", produces = APPLICATION_JSON_VALUE)
    public  List<Device> testx1() {
        List<Device> device = new ArrayList<>();
        device.add(new Device("Joe", "48"));
        return device;
    }

    @GetMapping(value = "/devicelist", produces = APPLICATION_JSON_VALUE)
    public  HashMap<String, String> devicelist() {
        HashMap<String, String> capitalCities = new HashMap<String, String>();
        capitalCities.put("England", "London");
        capitalCities.put("Germany", "Berlin");
        capitalCities.put("Norway", "Oslo");
        capitalCities.put("USA", "Washington DC");
      //  System.out.println(capitalCities);
        return capitalCities;
    }



    @GetMapping(value = "/products", produces = APPLICATION_JSON_VALUE)
    @ResponseStatus(OK)
    public ResponseEntity<List<Device>> saveProduct() {
        List<Device> device = new ArrayList<>();
        device.add(new Device("Joe", "48"));
        return new ResponseEntity<>(device, OK);
    }


/*
        @GetMapping(path = "/hello", produces=MediaType.APPLICATION_JSON_VALUE)
        public ResponseEntity<Object> sayHello()
        {
            //Get data from service layer into entityList.

            List<JSONObject> entities = new ArrayList<JSONObject>();
            for (Entity n : entityList) {
                JSONObject entity = new JSONObject();
                entity.put("aa", "bb");
                entities.add(entity);
            }
            return new ResponseEntity<Object>(entities, HttpStatus.OK);
        }*/



}

