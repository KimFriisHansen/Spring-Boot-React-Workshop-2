package com.bestseller.springboot.bsspringboot;


import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.boot.autoconfigure.SpringBootApplication;
//@RestController is a convenience annotation that is itself annotated with @Controller and @ResponseBody
@RestController

//@EnableAutoConfiguration enables auto-configuration of the Spring Application Context, attempting to guess
//and configure beans that you are likely to need.


@SpringBootApplication
public class BsSpringbootApplication {
    // @RequestMapping annotation is used for mapping web requests onto specific handler classes
    @RequestMapping("/")
    String basicURL() {
        return "Bestseller";
    }


    public static void main(String[] args) {
		SpringApplication.run(BsSpringbootApplication.class, args);
	}

}
