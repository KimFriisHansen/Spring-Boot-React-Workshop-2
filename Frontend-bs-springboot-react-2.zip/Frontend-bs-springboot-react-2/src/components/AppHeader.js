import React,{ Component } from 'react';
import logo from '../logo.svg';
import spiderbot from '../resources/images/spiderbot2.png';

class AppHeader extends Component{

    render() {
        return (
            <div className="App-header" Style={{left:"500"}}>

            </div>
        );
    }
}

export default AppHeader;