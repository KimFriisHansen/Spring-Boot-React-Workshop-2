/**
 * Created by master on 02/06/2017.
 */
export const FETCH_DEVICES = 'FETCH_DEVICES'